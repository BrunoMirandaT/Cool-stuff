package entidades;

import aplicacao.app;

public class calculo {
	
	public int opcao;
	public int repeat;
	public double num1;
	public double num2;
	public double num3;
	public double num4;
	public double num5;
	public double soma;
	public double sub;
	public double mult;
	public double div;
	public double pot;
	public double porc;
	public double raiz;
	
	app x = new app();
	
	public double soma() {
		switch(repeat) {
		case 1: return soma = num1;
		
		case 2: return soma = num1 + num2;
		
		case 3: return soma = num1 + num2 + num3;
		
		case 4: return soma = num1 + num2 + num3 + num4;
		
		case 5: return soma = num1 + num2 + num3 + num4 + num5;
		
		default: System.out.println("Numero invalido");
		return soma = 0;
		
		}
	}
	
	public double sub() {
		switch(repeat) {
		case 1: return sub = num1;
		
		case 2: return sub = num1 - num2;
		
		case 3: return sub = num1 - num2 - num3;
		
		case 4: return sub = num1 - num2 - num3 - num4;
		
		case 5: return sub = num1 - num2 - num3 - num4 - num5;
		
		default: System.out.println("Numero invalido");
		return sub = 0;
		
		}
	}
	
	public double mult() {
		switch(repeat) {
		case 1: return mult = num1;
		
		case 2: return mult = num1 * num2;
		
		case 3: return mult = num1 * num2 * num3;
		
		case 4: return mult = num1 * num2 * num3 * num4;
		
		case 5: return mult = num1 * num2 * num3 * num4 * num5;
		
		default: System.out.println("Numero invalido");
		return mult = 0;
		
		}
	}
	
	public double div() {
		switch(repeat) {
		case 1: return div = num1;
		
		case 2: return div = num1 / num2;
		
		case 3: return div = num1 / num2 / num3;
		
		case 4: return div = num1 / num2 / num3 / num4;
		
		case 5: return div = num1 / num2 / num3 / num4 / num5;
		
		default: System.out.println("Numero invalido");
		return div = 0;
		
		}
	}
	
	public double pot() {
		return pot = Math.pow(num1, num2);
	}
	
	public double porc() {
		return porc = num1 * (num2/100);
	}
	
	public double raiz() {
		return raiz = Math.sqrt(num1);
	}

}