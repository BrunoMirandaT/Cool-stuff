package aplicacao;

import java.util.Scanner;

import entidades.calculo;

public class app {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		calculo x = new calculo(); 
		
		System.out.println("1 - Soma\n2 - Subtracao\n3 - Multiplicacao\n4 - Divisao\n5 - Potenciacao\n"
				+ "6 - Porcentagem\n7 - Raiz quadrada\nEscolha uma opcao:");
		x.opcao = sc.nextInt();
		
		if(x.opcao < 5) {
		
		System.out.println("Quantos n�meros serao inseridos?");
		x.repeat = sc.nextInt();
		
		switch(x.repeat) {
		case 1: System.out.println("Informe o primeiro n�mero");
		x.num1 = sc.nextInt();
		break;
		
		case 2: System.out.println("Informe o primeiro n�mero");
		x.num1 = sc.nextInt();
		
		System.out.println("Informe o segundo n�mero");
		x.num2 = sc.nextInt();
		break;
		
		case 3: System.out.println("Informe o primeiro n�mero");
		x.num1 = sc.nextInt();
		
		System.out.println("Informe o segundo n�mero");
		x.num2 = sc.nextInt();
		
		System.out.println("Informe o terceiro n�mero");
		x.num3 = sc.nextInt();
		break;
		
		case 4: System.out.println("Informe o primeiro n�mero");
		x.num1 = sc.nextInt();
		
		System.out.println("Informe o segundo n�mero");
		x.num2 = sc.nextInt();
		
		System.out.println("Informe o terceiro n�mero");
		x.num3 = sc.nextInt();
		
		System.out.println("Informe o quarto n�mero");
		x.num4 = sc.nextInt();
		break;
		
		case 5: System.out.println("Informe o primeiro n�mero");
		x.num1 = sc.nextInt();
		
		System.out.println("Informe o segundo n�mero");
		x.num2 = sc.nextInt();
		
		System.out.println("Informe o terceiro n�mero");
		x.num3 = sc.nextInt();
		
		System.out.println("Informe o quarto n�mero");
		x.num4 = sc.nextInt();
		
		System.out.println("Informe o quinto n�mero");
		x.num5 = sc.nextInt();
		break;
		
		default: System.out.println("Quantidade invalida!");
		break;
		}
	}
		
		
		switch(x.opcao) {
		case 1: x.soma();
		System.out.println("O resultado da soma e "+x.soma);
		break;
		
		case 2: x.sub();
		System.out.println("O resultado da subtracao e "+x.sub);
		break;
		
		case 3: x.mult();
		System.out.println("O resultado da multiplicacao e "+x.mult);
		break;
		
		case 4: x.div();
		System.out.println("O resultado da divisao e "+x.div);
		break;
		
		case 5:
			System.out.println("Informe um numero:");
			x.num1 = sc.nextInt();
			
			System.out.println("Informe a potencia:");
			x.num2 = sc.nextInt();
			
			x.pot();
			System.out.println("O resultado da potenciacao e "+x.pot);
			break;
			
		case 6:
			System.out.println("Informe um numero:");
			x.num1 = sc.nextInt();
			
			System.out.println("Informe a porcentagem:");
			x.num2 = sc.nextInt();
			
			x.porc();
			System.out.println("O resultado da porcentagem e "+x.porc);
			break;
			
		case 7:
			System.out.println("Informe um numero:");
			x.num1 = sc.nextInt();
			
			x.raiz();
			System.out.println("O resultado da raiz quadrada e "+x.raiz);
			break;
			
		default: System.out.println("Opcao invalida!");
		break;
		}
		
		
		
		

	}

}
