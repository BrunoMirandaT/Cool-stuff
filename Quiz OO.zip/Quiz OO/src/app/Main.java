package app;

import java.util.Scanner;
import entidades.Quiz;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		/*Variaveis para salvar respostas para todas as perguntas e o total de acertos*/
		
		Quiz player = new Quiz();
		
		System.out.println("Quiz sobre o mundo!");
		/*Todas as perguntas do quiz em ordem, foi usado o \n para poder fazer uma quest�o inteira em 1 linha de c�digo*/
		System.out.println("1/10 - Quantos continentes tem no mundo?\n1 - 5\n2 - 6\n3 - 7\n4 - 4");
		player.per1 = sc.nextInt();
		
		System.out.println("2/10 - Qual � o maior continente do mundo?\n1 - Am�rica\n2 - �frica\n3 - Europa\n4 - �sia");
		player.per2 = sc.nextInt();
		
		System.out.println("3/10 - Qual pa�s pertence a dois continentes?\n1 - Egito\n2 - Ar�bia\n3 - �ndia\n4 - Alemanha");
		player.per3 = sc.nextInt();
		
		System.out.println("4/10 - Qual continente � banhado por apenas um oceano?\n1 - �sia\n2 - Oceania\n3 - Europa\n4 - �frica");
		player.per4 = sc.nextInt();
		
		System.out.println("5/10 - Qual continente � o menos populoso?(Antartida desconsiderada)\n1 - Oceania\n2 - �frica\n3 - Europa\n4 - Am�rica");
		player.per5 = sc.nextInt();
		
		System.out.println("6/10 - A qual continente a �ndia pertence?\n1 - Europa\n2 - �frica\n3 - Oceania\n4 - �sia");
		player.per6 = sc.nextInt();
		
		System.out.println("7/10 - Qual � o pa�s mais populoso da �sia?\n1 - �ndia\n2 - China\n3 - Jap�o\n4 - Ir�");
		player.per7 = sc.nextInt();
		
		System.out.println("8/10 - Qual � o continente dividido em 3?\n1 - Am�rica\n2 - Europa\n3 - Oceania\n4 - Ant�rtida");
		player.per8 = sc.nextInt();

		System.out.println("9/10 - Qual � o maior oceano do mundo?\n1 - �ndico\n2 - Atl�ntico\n3 - Pac�fico\n4 - �rtico");
		player.per9 = sc.nextInt();
		
		System.out.println("10/10 - Qual � a maior ilha do mundo?\n1 - Madagascar\n2 - Born�u\n3 - Nova Guin�\n4 - Groel�ndia");
		player.per10 = sc.nextInt();
		
		player.resposta();
		
		player.resultado();
		
		sc.close();
	}

}