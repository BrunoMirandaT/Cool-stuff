package entidades;

public class Quiz {
	
	public int per1;
	public int per2;
	public int per3;
	public int per4;
	public int per5;
	public int per6;
	public int per7;
	public int per8;
	public int per9;
	public int per10;
	public int resul = 0;
	
	public void resposta() {
	if(per1 == 2){
		resul+=1;
	}
	if(per2 == 4){
		resul+=1;
	}
	if(per3 == 1){
		resul+=1;
	}
	if(per4 == 3){
		resul+=1;
	}
	if(per5 == 1){
		resul+=1;
	}
	if(per6 == 4){
		resul+=1;
	}
	if(per7 == 2){
		resul+=1;
	}
	if(per8 == 1){
		resul+=1;
	}
	if(per9 == 3){
		resul+=1;
	}
	if(per10 == 4){
		resul+=1;
		
		}
	}
	
	public void resultado() {
		switch(resul) {
		case 0: System.out.println("Sua pontua��o: "+resul+"/10\nVoc� errou todas :(\nEstude mais!");
		break;
				
		case 1:
		case 2:
		case 3: System.out.println("Sua pontua��o: "+resul+"/10\nVoc� foi muito mal :(\nEstude mais!");
		break;
			
		case 4:
		case 5:
		case 6: System.out.println("Sua pontua��o: "+resul+"/10\nVoc� n�o foi muito mal mas ainda da pra melhorar muito!");
		break;
		
		case 7:
		case 8:
		case 9: System.out.println("Sua pontua��o: "+resul+"/10\nVoc� foi muito bem\nContinue estudando!");
		break;
			
		case 10: System.out.println("Sua pontua��o: "+resul+"/10\nParab�ns, voc� acertou todas!\nContinue se esfor�ando!");
		break;
		
		default: System.out.println("Se tu tiver lendo isso, o programa bugo :(");
		break;
		}
	}

}
